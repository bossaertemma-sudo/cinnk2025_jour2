#mon_projet-figma

##Structure HTML
- '<header>': marque +navbar + bouton pour joindre/ en savoir plus.
- '<section id="_1_2_Layout3">' Les différents Packages + lien pour en savoir plus + deux cartes de présentation.
- '<section id="_1_1_Layout2">' Vidéo en Live + Lien pour en savoir plus. 
- '<section id="_1_2_Layout2">'Les différents Packages + carroussel sur les prix.
- '<section id="_1_2_Layout5">' Témoignage 2 cartes allignées
- '<section id="_1_4_Layout2">' L'équipe + 4 cartes de contact allignées
- '<section id="_1_1_Layout1"> Newsletter + barre de souscription
- <article class="footer"> Informations et liens de contact

##Organisation
- 'index.html'page principale
- 'style.css' feuille de style externe
- '/Dossier_images/' dossier comptenant les images

##Déploiement
- Projet disponible à l'adresse en ligne 
https://vigilant-elbakyan.62-210-99-155.plesk.page/mon_projet-figma/

##Difficuletées rencontrées
- le temps : je tappe lentement + problèmes de compréhension des différence entre margin/padding ect.
- problème techniques: le non-fonctionnement de certaines commandes flex: soit je fais une faute que je ne comprends pas soit l'ordre m'échappe certainement à cause des contraintes des différents conteneurs et marges mal apppliquées.  
